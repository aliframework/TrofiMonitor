package trpl.nim234311030.trofimonitor

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun AddClubScreen(onAddClub: (Club) -> Unit) {
    var name by remember { mutableStateOf("") }
    var premierLeague by remember { mutableStateOf(0) }
    var faCup by remember { mutableStateOf(0) }
    var eflCup by remember { mutableStateOf(0) }
    var championsLeague by remember { mutableStateOf(0) }
    var europaLeague by remember { mutableStateOf(0) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        horizontalAlignment = Alignment.Start
    ) {
        Text(
            text = "Tambah Klub Baru",
            fontSize = 20.sp,
            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(16.dp))

        TextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Nama Klub") }
        )

        Spacer(modifier = Modifier.height(8.dp))

        TextField(
            value = premierLeague.toString(),
            onValueChange = { premierLeague = it.toIntOrNull() ?: 0 },
            label = { Text("Jumlah Trofi Premier League") }
        )

        Spacer(modifier = Modifier.height(8.dp))

        TextField(
            value = faCup.toString(),
            onValueChange = { faCup = it.toIntOrNull() ?: 0 },
            label = { Text("Jumlah Trofi FA Cup") }
        )

        Spacer(modifier = Modifier.height(8.dp))

        TextField(
            value = eflCup.toString(),
            onValueChange = { eflCup = it.toIntOrNull() ?: 0 },
            label = { Text("Jumlah Trofi EFL Cup") }
        )

        Spacer(modifier = Modifier.height(8.dp))

        TextField(
            value = championsLeague.toString(),
            onValueChange = { championsLeague = it.toIntOrNull() ?: 0 },
            label = { Text("Jumlah Trofi Champions League") }
        )

        Spacer(modifier = Modifier.height(8.dp))

        TextField(
            value = europaLeague.toString(),
            onValueChange = { europaLeague = it.toIntOrNull() ?: 0 },
            label = { Text("Jumlah Trofi Europa League") }
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = {
            // Buat objek Club baru
            val newClub = Club(name, premierLeague, faCup, eflCup, championsLeague, europaLeague)
            onAddClub(newClub) // Panggil fungsi untuk menambahkan klub
            // Reset input fields
            name = ""
            premierLeague = 0
            faCup = 0
            eflCup = 0
            championsLeague = 0
            europaLeague = 0
        }) {
            Text("Tambah Klub")
        }
    }
}
