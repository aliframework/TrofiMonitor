package trpl.nim234311030.trofimonitor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.add


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            StudentInfoScreen()
        }
    }
}

@Composable
fun StudentInfoScreen() {
    // Membuat daftar klub dengan jumlah trofi yang dapat disesuaikan
    val clubs = remember { mutableStateListOf<Club>() }
    clubs.addAll(
        listOf(
            Club("Liverpool", 19, 8, 10, 6, 3),
            Club("Manchester United", 20, 12, 6, 3, 1),
            Club("Arsenal", 6, 8, 5, 2, 2),
            Club("Manchester City", 9, 7, 8, 1, 0),
            Club("Chelsea", 13, 14, 2, 0, 0),
            Club("Tottenham Hotspur", 2, 8, 4, 0, 0)
        )
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Top,
        horizontalAlignment = Alignment.Start
    ) {
        // Tampilkan Nama dan NIM
        Text(
            text = "Nama: Alif Rahmathul Jadid",
            fontSize = 20.sp,
            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
        )
        Text(
            text = "NIM: 234311030",
            fontSize = 18.sp
        )

        Spacer(modifier = Modifier.height(20.dp)) // Tambahkan ruang antara info mahasiswa dan klub

        // Tampilkan informasi klub
        Text(
            text = "Informasi Klub Sepak Bola:",
            fontSize = 20.sp,
            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
        )

        // Panggil fungsi untuk menampilkan klub yang diurutkan dan difilter
        DisplayFilteredSortedClubs(clubs, 10) // Menggunakan ambang batas NIM
        DisplayClubsWithMoreThan30Trophies(clubs) // Menampilkan klub dengan lebih dari 30 trofi

        Spacer(modifier = Modifier.height(20.dp))
    }
}

@Composable
fun DisplayFilteredSortedClubs(clubs: List<Club>, nimThreshold: Int) {
    // Memfilter klub dengan total trofi lebih dari ambang batas NIM dan mengurutkan
    val filteredSortedClubs = clubs
        .filter { it.totalTrophies > nimThreshold } // Memfilter klub
        .sortedByDescending { it.totalTrophies } // Mengurutkan klub berdasarkan total trofi

    // Tampilkan setiap klub dan total trofi mereka
    if (filteredSortedClubs.isEmpty()) {
        Text(
            text = "Tidak ada klub dengan total trofi lebih dari $nimThreshold.",
            fontSize = 16.sp
        )
    } else {
        filteredSortedClubs.forEach { club ->
            Row(
                modifier = Modifier.padding(vertical = 8.dp), // Tambahkan padding vertikal
                verticalAlignment = Alignment.Top // Rata atas secara vertikal
            ) {
                // Menggunakan kondisional when untuk menampilkan logo sesuai nama klub
                val logoResId = when (club.name) {
                    "Liverpool" -> R.drawable.liverpool_logo
                    "Manchester United" -> R.drawable.mu_logo
                    "Arsenal" -> R.drawable.arsenal_logo
                    "Manchester City" -> R.drawable.mancity_logo
                    "Chelsea" -> R.drawable.chelsea_logo
                    "Tottenham Hotspur" -> R.drawable.tottenham_logo
                    else -> R.drawable.resource_default // Gambar default jika tidak ada yang cocok
                }

                // Menggunakan Image untuk menampilkan logo klub
                Image(
                    painter = painterResource(id = logoResId),
                    contentDescription = "${club.name} Logo",
                    modifier = Modifier.size(64.dp).padding(end = 8.dp)
                )
                var showAddClubScreen by remember { mutableStateOf(false) }

                // Menggunakan Column untuk menyusun teks
                Column {
                    Text(
                        text = "${club.name}: Total Trofi = ${club.totalTrophies}",
                        fontSize = 16.sp
                    )

                    // Cek apakah klub memiliki trofi internasional
                    if (club.championsLeague == 0 && club.europaLeague == 0) {
                        Text(
                            text = "${club.name} belum pernah memenangkan trofi internasional.",
                            fontSize = 14.sp,
                            color = androidx.compose.ui.graphics.Color.Red // Tampilkan pesan dalam warna merah
                        )
                        Button(onClick = { showAddClubScreen = true }) {
                            Text("Tambah Klub")
                        }

                        // Tampilkan AddClubScreen jika showAddClubScreen bernilai true
                        if (showAddClubScreen) {
                            AddClubScreen { newClub ->
                                clubs.add(newClub) // Menambahkan klub baru ke daftar
                                showAddClubScreen = false // Menyembunyikan AddClubScreen setelah menambahkan klub
                            }
                        }
                    }
                }
            }
        }
    }
}

// Fungsi untuk menampilkan klub dengan lebih dari 30 trofi
@Composable
fun DisplayClubsWithMoreThan30Trophies(clubs: List<Club>) {
    // Menggunakan lambda untuk memfilter klub dengan total trofi lebih dari 30
    val filterClubs = clubs.filter { it.totalTrophies > 30 } // Memfilter klub

    Text(
        text = "Klub dengan lebih dari 30 trofi:",
        fontSize = 20.sp,
        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
        modifier = Modifier.padding(top = 16.dp) // Tambahkan padding atas
    )

    if (filterClubs.isEmpty()) {
        Text(
            text = "Tidak ada klub dengan total trofi lebih dari 30.",
            fontSize = 16.sp
        )
    } else {
        filterClubs.forEach { club ->
            Row(
                modifier = Modifier.padding(vertical = 8.dp), // Tambahkan padding vertikal
                verticalAlignment = Alignment.Top // Rata atas secara vertikal
            ) {
                val logoResId = when (club.name) {
                    "Liverpool" -> R.drawable.liverpool_logo
                    "Manchester United" -> R.drawable.mu_logo
                    "Arsenal" -> R.drawable.arsenal_logo
                    "Manchester City" -> R.drawable.mancity_logo
                    "Chelsea" -> R.drawable.chelsea_logo
                    "Tottenham Hotspur" -> R.drawable.tottenham_logo
                    else -> R.drawable.resource_default // Gambar default jika tidak ada yang cocok
                }

                Image(
                    painter = painterResource(id = logoResId),
                    contentDescription = "${club.name} Logo",
                    modifier = Modifier.size(64.dp).padding(end = 8.dp)
                )

                Text(
                    text = "${club.name}: Total Trofi = ${club.totalTrophies}",
                    fontSize = 16.sp
                )
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewStudentInfoScreen() {
    StudentInfoScreen()
}
